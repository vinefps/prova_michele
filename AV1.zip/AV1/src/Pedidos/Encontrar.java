package Pedidos;

public class Encontrar {

    public static void main(String[] args) {
        // Inicializando um objeto do tipo Usuario
        Usuario usuario = new Usuario("Vinicius Silva", "vinicius.silva@example.com", "senha123");

        // Inicializando um objeto do tipo AchadoPerdido
        AchadoPerdido achadoPerdido = new AchadoPerdido("Chave de casa", "Chave encontrada na rua", "Objeto", "Encontrado");
        achadoPerdido.completaDados("foto_chave.jpg", "Rua A", "2023-10-05 14:30:00");

        // Exibindo detalhes do achado perdido
        System.out.println("Detalhes do achado perdido:");
        achadoPerdido.visualizarDetalhes();

        // Buscando título do achado perdido
        String tituloBuscado = "Chave de casa";
        String detalhesBuscados = achadoPerdido.buscarTitulo(tituloBuscado);
        if (detalhesBuscados != null) {
            System.out.println("\nDetalhes do achado perdido com o título '" + tituloBuscado + "':");
            System.out.println(detalhesBuscados);
        } else {
            System.out.println("\nAchado perdido com o título '" + tituloBuscado + "' não encontrado.");
        }
    }
}
