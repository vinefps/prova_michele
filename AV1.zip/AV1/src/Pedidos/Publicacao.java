package Pedidos;

public interface Publicacao {
    String buscarTitulo(String titulo);
    void visualizarDetalhes();
}
