package Projetos;

public class ProjetoSocial {
    public static void main(String[] args) {
        // Exemplo de uso das classes
        DistribuicaoAlimento distribuicaoAlimento = new DistribuicaoAlimento("Alimentos", "projeto","rua-xxx","04/05/2023","04/06/2024","muito ferro",5.3f);
        distribuicaoAlimento.setNomeProjeto("Projeto de Distribuição de Alimentos");
        distribuicaoAlimento.setDescricao("Projeto para distribuição de alimentos para pessoas carentes");
        distribuicaoAlimento.setEndereco("Rua Exemplo, 123");
        distribuicaoAlimento.setDataInicio("2023-10-10");
        distribuicaoAlimento.setDataFim("");  // DataFim vazia para teste

        TrabalhoVoluntario trabalhoVoluntario = new TrabalhoVoluntario("Assistência social", "Projeto Unico","Rua-xxx","02/04/2023","02/04/2024","Suporte",10);
        trabalhoVoluntario.setNomeProjeto("Projeto de Trabalho Voluntário");
        trabalhoVoluntario.setDescricao("Projeto para trabalho voluntário em assistência social");
        trabalhoVoluntario.setEndereco("Avenida Teste, 456");
        trabalhoVoluntario.setDataInicio("2023-11-01");
        trabalhoVoluntario.setDataFim("2023-11-10");

        // Validando e imprimindo os projetos
        System.out.println("Distribuição de Alimento - Validação: " + distribuicaoAlimento.validaProjeto(distribuicaoAlimento.getNomeProjeto()));
        System.out.println(distribuicaoAlimento.imprimeProjeto());

        System.out.println("\nTrabalho Voluntário - Validação: " + trabalhoVoluntario.validaProjeto(trabalhoVoluntario.getNomeProjeto()));
        System.out.println(trabalhoVoluntario.imprimeProjeto());
    }
}