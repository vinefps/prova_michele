package Projetos;

public abstract class Projeto {
    protected String nomeProjeto;
    protected String descricao;
    protected String endereco;
    protected String datainicio;
    protected String datafim;

    public Projeto(String nome, String descricao, String endereco, String datainicio, String datafim) {
        this.nomeProjeto = nome;
        this.descricao = descricao;
        this.endereco = endereco;
        this.datainicio = datainicio;
        this.datafim = datafim;
    }

    public abstract boolean validaProjeto(String nomeProjeto);

    public abstract String imprimeProjeto();

    public String getNomeProjeto() {
        return nomeProjeto;
    }

    public void setNomeProjeto(String nomeProjeto) {
        this.nomeProjeto = nomeProjeto;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getDataInicio() {
        return datainicio;
    }

    public void setDataInicio(String datainicio) {
        this.datainicio = datainicio;
    }

    public String getDataFim() {
        return datafim;
    }

    public void setDataFim(String datafim) {
        this.datafim = datafim;
    }
}